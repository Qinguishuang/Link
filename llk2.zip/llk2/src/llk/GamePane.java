package llk;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * չʾ��Ϸ����
 * 
 * @author Administrator
 */
public class GamePane extends Application {
    public DataOfGamePane data = null;// ��¼��Ϸ��������
    private Button[][] pictureButton; // �����濴Ϊһ����ά����
    private int[][] pictureCount; // ��¼�����ͼƬ
    private Event event = null; // ��ť�������¼�
    private GridPane gridPane; // ��Ϸ��������
    private final int BUTTONLENTH = 66;// ��ť����
    private final int BUTTONWIDE = 58;// ��ť����
    private Label warm = new Label(" ʣ��\n ʱ��");
    private Label time = new Label("");// ����ʱ
    private Grade grade = null;
    private String gameLevel;
    private String[] userMessage = null;
    static int allTime;
    /**
     * ��Ϸ������������ܰ�ť
     */
    private Button exitButton = new Button("", new ImageView(new Image("\\images\\�˳�.jpg"))); // �˳�
    private Button boomButton = new Button("", new ImageView(new Image("\\images\\ը��.jpg"))); // ը��
    private Button restartButton = new Button("", new ImageView(new Image("\\images\\���¿�ʼ.jpg"))); // ���¿�ʼ

    /**
     * ȷ����Ϸ��������
     * 
     * @param gameLevel
     *            ��Ϸ�Ѷ�
     * @param userMessage
     *            �û���Ϣ
     */
    public GamePane(String gameLevel, String[] userMessage) {
        grade = new Grade(userMessage);
        this.gameLevel = gameLevel;
        this.userMessage = userMessage;
        data = new DataOfGamePane(gameLevel);
    }

    /**
     * ȷ����Ϸ��������
     * 
     * @param lenthButton
     *            �а�ť����
     * @param wideButton
     *            �а�ť����
     * @param userMessage
     *            �û���Ϣ
     */
    public GamePane(int lenthButton, int wideButton, String[] userMessage) {
        this.userMessage = userMessage;
        data = new DataOfGamePane(lenthButton, wideButton);
    }

    /**
     * չʾ��Ϸ����
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        gridPane = new GridPane();
        // ��Ϸ����
        pictureButton = new Button[data.wideButton + 2][data.lenthButton + 2];
        pictureCount = new int[data.wideButton][data.lenthButton];
        event = new Event(pictureCount, BUTTONLENTH, BUTTONWIDE, grade, gameLevel, userMessage);
        // ȷ��ͼƬ����
        decidePictureCount(data.pictureNumber, data.lenthButton);
        // ���Ӱ�ť
        addButton();
        // �����ĸ�������ť
        gridPane.add(exitButton, 0, 0);
        gridPane.add(boomButton, 1, 0);
        gridPane.add(restartButton, 2, 0);
        time.setFont(Font.font(25));
        gridPane.add(time, pictureButton[0].length - 1, 0);
        warm.setFont(Font.font(23));
        gridPane.add(warm, pictureButton[0].length - 2, 0);

        // �����¼�
        event.addEvent(pictureButton, gridPane, primaryStage, exitButton, boomButton, restartButton);

        // �ǽ����������Ӽ���û�õİ�ť
        addUselessButton();
        // ʹ�ö��߳����ӵ���ʱ
        allTime = (pictureButton.length - 2) * (pictureButton[0].length - 2) * 3;
        new Thread(new Runnable() {
            int gradeTime = allTime;

            @Override
            public void run() {
                try {
                    while (allTime > 0) {
                        event.gradeTime = gradeTime - allTime;
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                if (event.isButtonOver(pictureButton)) {
                                    allTime++;
                                }
                                if (allTime <= 10) {
                                    time.setTextFill(Color.RED);
                                    time.setFont(Font.font(45));
                                }
                                time.setText(" " + (--allTime));
                                if (allTime == 0) {
                                    try {
                                        new LostGamePane(userMessage).start(primaryStage);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }

                        });
                        Thread.sleep(1000);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        gridPane.setStyle("-fx-background-image : url(images/����.jpg)");
        Scene s = new Scene(gridPane, (data.lenthButton + 2) * BUTTONLENTH, (data.wideButton + 2) * BUTTONWIDE);
        primaryStage.setScene(s);
        primaryStage.setTitle("������");
        primaryStage.show();
    }

    /**
     * ������Ϸ���� �������õİ�ť
     */
    private void addUselessButton() {
        for (int i = 0; i < pictureButton[0].length + 1; i++) {
            Button b = new Button("", new ImageView(new Image("\\images\\1.jpg")));
            gridPane.add(b, i, pictureButton.length);
            b.setVisible(false); // ��ť���ɼ�
        }
        for (int i = 0; i < pictureButton.length + 1; i++) {
            Button b = new Button("", new ImageView(new Image("\\images\\1.jpg")));
            gridPane.add(b, pictureButton[0].length, i);
            b.setVisible(false);
        }
    }

    /**
     * ����Ϸ���������Ӱ�ť
     */
    private void addButton() {
        for (int i = 1; i <= pictureButton.length - 2; i++) {
            for (int j = 1; j <= pictureButton[i].length - 2; j++) {
                pictureButton[i][j] = new Button("",
                        new ImageView(new Image("\\images\\" + pictureCount[i - 1][j - 1] + ".jpg")));
                gridPane.add(pictureButton[i][j], j, i);
            }
        }
    }

    /**
     * ȷ����Ϸ�����ͼƬ������
     * 
     * @param pictureNumber
     *            ����ͼƬ��
     * @param lenthButton
     *            ÿһ��ͼƬ����
     */
    private void decidePictureCount(int pictureNumber, int lenthButton) {
        int flag = pictureNumber;
        // �к���ͼƬ��������һ��Ϊż��
        // ȷ��ΪͼƬ���ִ���Ϊż��
        if (lenthButton % 2 != 0) {
            for (int j = 0; j < pictureCount[0].length; j++) {
                for (int i = 0; i < pictureCount.length; i += 2) {
                    pictureCount[i][j] = flag;
                    pictureCount[i + 1][j] = flag;
                    flag++;
                    if (flag > pictureNumber) {
                        flag = 1;
                    }
                }
            }
        } else {
            for (int i = 0; i < pictureCount.length; i++) {
                for (int j = 0; j < pictureCount[i].length; j += 2) {
                    pictureCount[i][j] = flag;
                    pictureCount[i][j + 1] = flag;
                    flag++;
                    if (flag > pictureNumber) {
                        flag = 1;
                    }
                }
            }
        }
        // �������
        for (int i = 0; i < pictureCount.length; i++) {
            for (int j = 0; j < pictureCount[i].length; j++) {
                int i1 = (int) (Math.random() * pictureCount.length);
                int j1 = (int) (Math.random() * pictureCount[i].length);

                int temp = pictureCount[i][j];
                pictureCount[i][j] = pictureCount[i1][j1];
                pictureCount[i1][j1] = temp;
            }
        }
    }

}
