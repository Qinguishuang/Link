package llk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * ��ʾ��¼����
 * 
 * @author Administrator
 *
 */
public class LoginPane extends Application {
    /**
     * ��ʾ����
     */
    private Label accountNumber = new Label(), password = new Label();
    /**
     * �û���Ϣ
     */
    String[] userMessage = new String[7];
    /**
     * ��ܰ��ʾ
     */
    private Label tips = new Label(), isSuccess = new Label();
    /**
     * �����
     */
    private TextField numberString = new TextField();
    private PasswordField passString = new PasswordField();
    /**
     * ��ʾע��
     */
    private Label register = new Label("��û���˺�\n����ע��!!!\n\n\n");
    /**
     * ��½��ť
     */
    private Button login = new Button("��¼");

    public static void main(String[] args) {
        launch(args);
    }

    /**
     * չʾ��¼����
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane gridPane = new GridPane();

        tips.setText("��ӭ��¼������\n  ");
        accountNumber.setText("�����˺�:");
        password.setText("��������:");

        accountNumber.setFont(Font.font(20));
        password.setFont(Font.font(20));
        tips.setFont(Font.font(20));
        login.setFont(Font.font(15));

        gridPane.setAlignment(Pos.CENTER);
        GridPane.setHalignment(login, HPos.RIGHT);
        GridPane.setHalignment(register, HPos.RIGHT);
        numberString.setAlignment(Pos.BOTTOM_RIGHT);
        passString.setAlignment(Pos.BOTTOM_RIGHT);

        gridPane.setHgap(20);
        gridPane.setHgap(20);
        gridPane.add(tips, 1, 0);

        gridPane.add(accountNumber, 0, 1);
        gridPane.add(numberString, 1, 1);

        gridPane.add(password, 0, 2);
        gridPane.add(passString, 1, 2);

        gridPane.add(login, 1, 4);
        gridPane.add(register, 1, 3);
        register.setUnderline(true);
        gridPane.add(isSuccess, 0, 3);
        isSuccess.setTextFill(Color.RED);

        gridPane.setStyle("-fx-background-image : url(images/����.jpg)");
        Scene s = new Scene(gridPane, 500, 300);
        primaryStage.setScene(s);
        primaryStage.setTitle("��¼");
        primaryStage.show();

        login.setOnMouseClicked(e -> {
            String AccountNumber = numberString.getText();
            String Passwords = passString.getText();

            Connection conn = null;
            ResultSet rs = null;
            PreparedStatement ps = null;
            boolean flag = false;

            try {
                // ע������
                Class.forName("com.mysql.jdbc.Driver");
                // ��ȡ���ݿ�����
                String url = "jdbc:mysql://localhost:3306/mydata"
                        + "?useUnicode=true&characterEncoding=utf-8&useSSL=false";
                String user = "root";
                String password = "root";
                conn = DriverManager.getConnection(url, user, password);
                // ����SQL�����
                String sql = "select * from usermessage " 
                        + "where AccountNumber = ? and Passwords = ?";
                // ִ��Ԥ�������
                ps = conn.prepareStatement(sql);
                // ��SQL��丳ֵ
                ps.setString(1, AccountNumber);
                ps.setString(2, Passwords);
                // ִ��
                rs = ps.executeQuery();
                if (rs.next()) {
                    flag = true;
                }
                if (flag) {
                    userMessage[0] = rs.getString(1);
                    userMessage[1] = rs.getString(2);
                    userMessage[2] = rs.getString(3);
                    userMessage[3] = rs.getString(4);
                    if (rs.getInt(5) != 0) {
                        userMessage[4] = String.valueOf((int) (rs.getInt(5)));
                    } else {
                        userMessage[4] = null;
                    }
                    if (rs.getInt(6) != 0) {
                        userMessage[5] = String.valueOf((int) (rs.getInt(6)));
                    } else {
                        userMessage[5] = null;
                    }
                    if (rs.getInt(7) != 0) {
                        userMessage[6] = String.valueOf((int) (rs.getInt(7)));
                    } else {
                        userMessage[6] = null;
                    }
                }

            } catch (Exception e2) {
                e2.printStackTrace();
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (ps != null) {
                        ps.close();
                    }
                    if (conn != null) {
                        conn.close();
                    }
                } catch (Exception e3) {
                    e3.printStackTrace();
                }
            }
            if (flag) {
                try {
                    new BeginMain(userMessage).start(new Stage());
                    primaryStage.close();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            } else {
                isSuccess.setText("�����˺Ż�����\n����,����������");
                numberString.setText("");
                passString.setText("");
            }

        });

        register.setOnMouseClicked(e -> {
            try {
                primaryStage.close();
                new RegisterPane().start(new Stage());
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }

}
