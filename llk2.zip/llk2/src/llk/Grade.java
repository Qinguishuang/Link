package llk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Grade {
    /**
     * �û���Ϣ
     */
    private String[] userMessage = new String[7];

    /**
     * Ĭ���޲ι��췽��
     */
    public Grade() {
    }

    /**
     * ��ʼ���û���Ϣ
     * 
     * @param userMessage
     *            �û���Ϣ
     */
    public Grade(String[] userMessage) {
        this.userMessage = userMessage;
    }

    /**
     * ��¼�ɼ�
     * 
     * @param thisTime
     *            ������Ϸʱ��
     * @param gameLevel
     *            ��Ϸ�Ѷ�
     */
    public void recordGrade(int thisTime, String gameLevel) {
        if (userMessage[4] == null
                || (gameLevel.compareTo("easy") == 0 && thisTime < Integer.parseInt(userMessage[4]))) {
            changeGrade("lowTime", thisTime);
        } else if (userMessage[5] == null
                || (gameLevel.compareTo("normal") == 0 && thisTime < Integer.parseInt(userMessage[5]))) {
            changeGrade("normalTime", thisTime);
        } else if (userMessage[6] == null
                || (gameLevel.compareTo("difficult") == 0 && thisTime < Integer.parseInt(userMessage[6]))) {
            changeGrade("difficultTime", thisTime);
        }
    }

    /**
     * �޸����ݿ�����
     * 
     * @param gameLevel
     *            ��Ϸ�Ѷ�
     * @param thisTime
     *            ��Ϸʱ��
     */
    private void changeGrade(String gameLevel, int thisTime) {
        switch (gameLevel) {
        case "lowTime":
            userMessage[4] = String.valueOf(thisTime);
            break;
        case "normalTime":
            userMessage[5] = String.valueOf(thisTime);
            break;
        case "difficultTime":
            userMessage[6] = String.valueOf(thisTime);
            break;
        }
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/mydata" 
                    + "?useUnicode=true&characterEncoding=utf-8&useSSL=false";
            String user = "root";
            String password = "root";
            conn = DriverManager.getConnection(url, user, password);
            //�������ݿ�
            String sql = "update usermessage set " + gameLevel + " = ? where accountnumber = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, thisTime);
            ps.setString(2, userMessage[2]);
            int count = ps.executeUpdate();
            //չʾ��ϲ����
            if (count == 1) {
                showCongratulation(new Stage());
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e2) {
            e2.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * չʾ��ף����
     * 
     * @param stage
     *            ��̨
     */
    private void showCongratulation(Stage stage) {
        VBox vbox = new VBox(20);
        Label l = new Label("��ϲ,�����¼�¼!!!");
        vbox.requestFocus();
        l.setTextFill(Color.RED);
        l.setFont(Font.font(20));
        Button sure = new Button("ȷ��");
        vbox.getChildren().addAll(l, sure);
        vbox.setAlignment(Pos.CENTER);
        Scene s = new Scene(vbox, 200, 140);
        stage.setTitle("��ϲ");
        stage.setScene(s);
        stage.show();
        sure.setOnMouseClicked(e -> {
            stage.close();
        });
    }
}
