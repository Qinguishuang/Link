package llk;
import java.util.Random;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * �����¼���
 * 
 * @author Administrator
 *
 */
public class Event {
    private int[][] pictureCount;
    private HandleEvent judgeMove;
    private int X, Y;
    private int defaultX = 1, defaultY = 1;
    private final int BUTTONLENTH, BUTTONWIDE;
    private int boom = 3;
    private Grade grade;
    private String gameLevel;
    public int gradeTime;
    private String[] userMessage = new String[7];

    /**
     * ��ʼ��
     * 
     * @param pictureCount
     *            ͼƬ��
     * @param BUTTONLENTH
     *            ��ť����
     * @param BUTTONWIDE
     *            ��ť����
     * @param grade
     *            ����
     * @param gameLevel
     *            ��Ϸ�Ѷ�ˮƽ
     * @param userMessage
     *            �û���Ϣ
     */
    public Event(int[][] pictureCount, int BUTTONLENTH, int BUTTONWIDE, Grade grade, String gameLevel,
            String[] userMessage) {
        this.pictureCount = pictureCount;
        this.BUTTONLENTH = BUTTONLENTH;
        this.BUTTONWIDE = BUTTONWIDE;
        this.grade = grade;
        this.gameLevel = gameLevel;
        this.userMessage = userMessage;
    }

    /**
     * �����¼�
     * 
     * @param pictureButton
     *            ���水ť������
     * @param gridPane
     *            ���ð�ť�����
     * @param primaryStage
     *            ��̨
     * @param exitButton
     *            ��Ϸ���湦�ܰ�ť
     * @param boomButton
     *            ��Ϸ���湦�ܰ�ť
     * @param restartButton
     *            ��Ϸ���湦�ܰ�ť
     */
    public void addEvent(Button[][] pictureButton, GridPane gridPane, Stage primaryStage, Button exitButton,
            Button boomButton, Button restartButton) {
        for (int i = 1; i <= pictureButton.length - 2; i++) {
            for (int j = 1; j <= pictureButton[i].length - 2; j++) {

                pictureButton[i][j].setOnMouseClicked(e -> {
                    // �洢�����ť��λ��
                    Y = (int) (e.getSceneX() / BUTTONLENTH);
                    X = (int) (e.getSceneY() / BUTTONWIDE);

                    if (pictureButton[X][Y] != null && pictureButton[defaultX][defaultY] != null) {
                        judgeMove = new HandleEvent(X, Y, defaultX, defaultY, pictureCount);
                        // �ж��ܷ�����
                        if (judgeMove.judge(pictureButton)) {
                            // �Ƴ���ť
                            moveButton(pictureButton, gridPane);
                            if (isButtonOver(pictureButton)
                                    && (gameLevel == "easy" || gameLevel == "normal" || gameLevel == "difficult")) {
                                grade.recordGrade(gradeTime, gameLevel);
                            }
                        }
                    }
                    // ͼƬ��ͬ ���ڶ��ε����λ�ø�ֵ��Ĭ��λ��
                    defaultX = X;
                    defaultY = Y;
                });
            }
        }

        restartButton.setOnMouseClicked(e1 -> {
            try {
                // ���¿�ʼ��ť
                // �رյ�ǰ����
                GamePane.allTime = -1;
                primaryStage.close();
                // �����ν���
                new BeginMain(userMessage).start(primaryStage);

            } catch (Exception exc1) {
                exc1.printStackTrace();
            }
        });
        // ը����ť
        boomButton.setOnMouseClicked(e2 -> {
            // ����Ƴ�������ť
            moveRandomButton(pictureButton, gridPane);
        });
        // �˳���ť // �����˳�����
        exitButton.setOnMouseClicked(e3 -> {
            try {
                // �Ƴ����а�ť
                gridPane.getChildren().removeAll(restartButton, exitButton, boomButton);
                // ��������
                StackPane stackPane = new StackPane();
                Label label = new Label("�� ��");
                label.setFont(Font.font(60));
                FadeTransition ft = new FadeTransition(Duration.millis(1000), label);
                ft.setFromValue(1.0);
                ft.setToValue(0.2);
                ft.setCycleCount(4);
                ft.setAutoReverse(true);
                stackPane.getChildren().add(label);
                Scene s = new Scene(stackPane, pictureButton[0].length * BUTTONLENTH,
                        pictureButton.length * BUTTONWIDE);
                stackPane.setStyle("-fx-background-image : url(images/����.jpg)");
                primaryStage.setScene(s);
                primaryStage.show();
                ft.play();
                // һ�����Ժ����ر�
                new Thread(new Runnable() {
                    long begin = System.currentTimeMillis();
                    long end = System.currentTimeMillis();

                    @Override
                    public void run() {
                        while (true) {
                            label.setTextFill(Color.GREEN.brighter());
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e1) {
                                e1.printStackTrace();
                            }
                            if (end - begin > 1000) {
                                System.exit(0);
                            }
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    label.setTextFill(Color.YELLOW);
                                    end = System.currentTimeMillis();
                                }
                            });
                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }).start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    /**
     * ����Ƴ���ť
     * 
     * @param pictureButton
     *            ���水ť������
     * @param gridPane
     *            ���ְ�ť�����
     */
    private void moveRandomButton(Button[][] pictureButton, GridPane gridPane) {
        if ((boom--) > 0 && (!isButtonOver(pictureButton))) {
            int mark = 1;
            do {
                Random r = new Random();
                while (true) {
                    // �������һ����ɫ�İ�ť
                    X = r.nextInt(pictureButton.length - 2) + 1;
                    Y = r.nextInt(pictureButton[0].length - 2) + 1;
                    if (pictureButton[X][Y] != null) {
                        break;
                    }

                }
                for (int i = 0; i < pictureCount.length; i++) {
                    for (int j = 0; j < pictureCount[i].length; j++) {
                        // �ҵ���һ����ɫ��ͬ�İ�ť
                        if ((pictureCount[i][j] == pictureCount[X - 1][Y - 1]) && (i != (X - 1) || j != (Y - 1))) {
                            defaultX = i + 1;
                            defaultY = j + 1;
                            if (pictureButton[defaultX][defaultY] != null) {
                                mark = 0;
                                break;
                            }
                        }
                    }
                    if (mark == 0) {
                        break;
                    }
                }
            } while (mark == 1);
            moveButton(pictureButton, gridPane);
        } else {
            // ը��������չʾ�������
            showWarming(new Stage());
        }
    }

    /**
     * ը��������ʾ�������
     * 
     * @param stage
     */
    private void showWarming(Stage stage) {
        VBox vbox = new VBox(20);
        Label l = new Label("ը��������!!!");
        vbox.setStyle("-fx-background-image : url(images/BoomPicture.png)");
        vbox.requestFocus();
        l.setTextFill(Color.RED);
        l.setFont(Font.font(25));
        Button sure = new Button("ȷ��");
        vbox.getChildren().addAll(l, sure);
        vbox.setAlignment(Pos.CENTER);
        Scene s = new Scene(vbox, 200, 140);
        stage.setTitle("����");
        stage.setScene(s);
        stage.show();
        sure.setOnMouseClicked(e -> {
            stage.close();
        });
    }

    /**
     * ��������ʱ�Ƴ���ť
     * 
     * @param pictureButton
     *            װ��ť������
     * @param gridPane
     *            ���ְ�ť������
     */
    private void moveButton(Button[][] pictureButton, GridPane gridPane) {
        // ����ť���������ȥ
        gridPane.getChildren().removeAll(pictureButton[X][Y], pictureButton[defaultX][defaultY]);
        // ����ť����������ȥ
        pictureButton[X][Y] = null;
        pictureButton[defaultX][defaultY] = null;

        if ((X == 1 && Y == 1) || (defaultX == 1 && defaultY == 1)) {
            pictureCount[0][0] = -1;
        }
        defaultX = 1;
        defaultY = 1;
        if (isButtonOver(pictureButton)) {
            new ButtonOverPane().setButtonOverLabel(pictureButton, gridPane);
        }

    }

    /**
     * �жϽ������Ƿ���ͼƬ
     * 
     * @param pictureButton
     *            װ��ť������
     * @return �а�ť����true û�а�ť����false
     */
    public boolean isButtonOver(Button[][] pictureButton) {
        for (int i = 1; i < pictureButton.length - 1; i++) {
            for (int j = 1; j < pictureButton[i].length - 1; j++) {
                if (pictureButton[i][j] != null) {
                    return false;
                }
            }
        }
        // grade.recordGrade(gradeTime, gameLevel);
        return true;
    }

}
