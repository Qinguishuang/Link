package llk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * ��ʾע�����
 * 
 * @author Administrator
 *
 */
public class RegisterPane extends Application {
    /**
     * ��ʾ��Ϣ
     */
    private Label welcomeLogin = new Label("��ӭע��"), loginNumber = new Label("����������:"),
            loginPassword = new Label("��������������(8-16λ):"), SureLoginPassword = new Label("���ٴ�������������:"),
            mentionLogin = new Label(), name = new Label("����:"), gender = new Label("�Ա�:");
    /**
     * �Ա���ʾ��
     */
    private ComboBox<String> cbo1 = null;
    /**
     * �����
     */
    private TextField number = new TextField(), nameString = new TextField();
    private PasswordField password = new PasswordField();
    private PasswordField surePassword = new PasswordField();
    /**
     * ���ע�ᰴť
     */
    private Button login = new Button("ע��");
    private GridPane gridPane = null;

    /**
     * չʾע�����
     */
    @Override
    public void start(Stage primaryStage) throws Exception {

        gridPane = new GridPane();
        // ������ʾ��Ϣ�����С
        welcomeLogin.setFont(Font.font(20));
        loginNumber.setFont(Font.font(20));
        loginPassword.setFont(Font.font(20));
        SureLoginPassword.setFont(Font.font(15));
        login.setFont(Font.font(15));
        SureLoginPassword.setFont(Font.font(20));
        name.setFont(Font.font(20));
        gender.setFont(Font.font(20));
        // �����������λ��
        gridPane.setAlignment(Pos.CENTER);
        GridPane.setHalignment(login, HPos.RIGHT);
        number.setAlignment(Pos.BOTTOM_RIGHT);
        password.setAlignment(Pos.BOTTOM_RIGHT);
        surePassword.setAlignment(Pos.BOTTOM_RIGHT);
        nameString.setAlignment(Pos.BOTTOM_RIGHT);

        cbo1 = new ComboBox<String>();
        cbo1.getItems().addAll("��", "Ů");

        gridPane.setHgap(20);
        gridPane.setHgap(20);

        gridPane.add(welcomeLogin, 1, 0);
        gridPane.add(name, 0, 1);
        gridPane.add(nameString, 1, 1);
        gridPane.add(gender, 0, 2);
        gridPane.add(cbo1, 1, 2);
        gridPane.add(loginNumber, 0, 3);
        gridPane.add(number, 1, 3);
        gridPane.add(loginPassword, 0, 4);
        gridPane.add(password, 1, 4);
        gridPane.add(SureLoginPassword, 0, 5);
        gridPane.add(surePassword, 1, 5);
        gridPane.add(login, 1, 6);

        gridPane.add(mentionLogin, 0, 6);
        mentionLogin.setFont(Font.font(13));
        mentionLogin.setTextFill(Color.RED);

        gridPane.setStyle("-fx-background-image : url(images/����.jpg)");
        Scene s = new Scene(gridPane, 500, 300);
        primaryStage.setScene(s);
        primaryStage.setTitle("ע��");
        primaryStage.show();

        login.setOnMouseClicked(e -> {
            String zh = number.getText();
            String mm = password.getText();
            String smm = surePassword.getText();
            // ���������ʽƥ��������˺������Ƿ���Ϲ���
            String regex1 = "\\w{6,12}@[a-zA-Z0-9]+\\.([a-zA-Z]+){1,3}";
            String regex2 = "[a-zA-Z0-9]{8,16}";
            boolean firstJudge = true;
            if (!mm.equals(smm) || mm == null || smm == null) {
                mentionLogin.setText("�������벻һ��");
                firstJudge = false;
            }
            if (nameString.getText() == null || cbo1.getValue() == null) {
                mentionLogin.setText("�뽫��Ϣ��������");
                firstJudge = false;
            }
            if (firstJudge) {
                if (zh.matches(regex1) && mm.matches(regex2)) {
                    loginMySQL(primaryStage);
                } else {
                    mentionLogin.setText("�˺Ż������ʽ����\n       ע��ʧ��");
                }
            }

        });

    }

    /**
     * �������ݿ� �����û���Ϣ
     * 
     * @param primaryStage
     *            ���������ʾ�Ƿ�ע��ɹ�
     */
    private void loginMySQL(Stage primaryStage) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        String sql = "insert into usermessage(name, gender, AccountNumber, Passwords) " + "values ('"
                + nameString.getText() + "', '" + cbo1.getValue() + "', '" + number.getText() + "', '"
                + password.getText() + "')";
        int count = 0;
        try {
            boolean isHave = false;
            String url = "jdbc:mysql://localhost:3306/mydata" + "?useUnicode=true&characterEncoding=utf-8&useSSL=false";
            String user = "root";
            String password = "root";
            // ע������
            Class.forName("com.mysql.jdbc.Driver");
            // ��ȡ���ݿ�����
            conn = DriverManager.getConnection(url, user, password);
            // ��ȡ���ݿ��������
            stmt = conn.createStatement();
            // ִ��SQL���
            String judgeNumber = "select AccountNumber from usermessage";
            rs = stmt.executeQuery(judgeNumber);
            // ������ѯ�����
            while (rs.next()) {
                // �ж������Ƿ��Ѿ�����
                String beenHave = rs.getString("AccountNumber");
                if (beenHave.equals(number.getText())) {
                    isHave = true;
                    mentionLogin.setText("�������Ѵ���,ע��ʧ��");
                    break;
                }
            }
            if (!isHave) { // �������ݿ�
                count = stmt.executeUpdate(sql);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        if (count == 1) {
            mentionLogin.setText("��ϲ��,ע��ɹ�\n���ҷ��ص�¼");
            mentionLogin.setUnderline(true);
            mentionLogin.setOnMouseClicked(e -> {
                try {
                    // �ر�ע�����
                    // �ص���¼����
                    primaryStage.close();
                    new LoginPane().start(new Stage());
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            });

        } else {
            if (mentionLogin.getText() == null) {
                mentionLogin.setText("�Բ���,ע��ʧ��,������ע��");
            }
        }
    }
}
