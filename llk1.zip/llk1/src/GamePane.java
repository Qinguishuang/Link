import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GamePane extends Application {
    public DataOfGamePane data  = null;//��¼��Ϸ��������
    private Button[][] pictureButton;	//�����濴Ϊһ����ά����
    private int[][] pictureCount;	//��¼�����ͼƬ
    private Event event = null;	//��ť�������¼�
    private GridPane gridPane;		//��Ϸ��������
    private int buttonLenth = 66;//��ť����
    private int buttonWide = 58;//��ť����
    private Label warm = new Label(" ʣ��\n ʱ��");
    private Label time= new Label("");//����ʱ
    private Button exitButton = new Button("", new ImageView(new Image("�˳�.jpg")));	//�˳�
    private Button boomButton = new Button("", new ImageView(new Image("ը��.jpg")));	//ը��
    private Button restartButton = new Button("", new ImageView(new Image("���¿�ʼ.jpg")));		//���¿�ʼ

    //��������  ȷ����Ϸ��������
    public GamePane(String gameLevel) {
        data = new DataOfGamePane(gameLevel);
    }
    public GamePane(int lenthButton, int wideButton) {
        data = new DataOfGamePane(lenthButton, wideButton);  
    }
   
    @Override
    public void start(Stage primaryStage) throws Exception {
        gridPane = new GridPane();
        //��Ϸ����  
        pictureButton = new Button[data.wideButton + 2][data.lenthButton + 2];
        pictureCount = new int[data.wideButton][data.lenthButton];
        event = new Event(pictureCount, buttonLenth, buttonWide);
        //ȷ��ͼƬ����
        decidePictureCount(data.pictureNumber,  data.lenthButton);
        //���Ӱ�ť
        addButton();
        //�����ĸ�������ť        
        gridPane.add(exitButton, 0, 0);
        gridPane.add(boomButton, 1, 0);
        gridPane.add(restartButton, 2, 0);
        time.setFont(Font.font(20));
        gridPane.add(time, pictureButton[0].length - 1, 0);
        warm.setFont(Font.font(23));
        gridPane.add(warm, pictureButton[0].length - 2, 0);
                
        
        //�����¼�
        event.addEvent(pictureButton, gridPane, primaryStage, 
        		exitButton, boomButton, restartButton);
        
        //�ǽ����������Ӽ���û�õİ�ť
        addUselessButton();
        //ʹ�ö��߳����ӵ���ʱ
         new Thread(new Runnable() {
			int allTime = (pictureButton.length - 2) * (pictureButton[0].length - 2) * 3;
			@Override
			public void run() {
				try {
					while(allTime > 0) {
						Platform.runLater(new Runnable() {							
							@Override
							public void run() {
								if(event.isButtonOver(pictureButton)) {
									allTime ++;
								}
								time.setText("   " + (--allTime));								
								if(allTime == 0) {									
									try {
										new LostGamePane().start(primaryStage);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}
						});
						Thread.sleep(1000);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start();
        
        Scene s = new Scene(gridPane, (data.lenthButton + 2) * buttonLenth, (data.wideButton + 2) * buttonWide);
        primaryStage.setScene(s);
        primaryStage.setTitle("������");
        primaryStage.show();
    }
    //�������õİ�ť
    private void addUselessButton() {
        for (int i = 0; i < pictureButton[0].length + 1; i++) {
            Button b = new Button("", new ImageView(new Image("1.jpg")));
            gridPane.add(b, i, pictureButton.length);
            b.setVisible(false); // ��ť���ɼ�
        }
        for (int i = 0; i < pictureButton.length + 1; i++) {
            Button b = new Button("", new ImageView(new Image("1.jpg")));
            gridPane.add(b, pictureButton[0].length, i);
            b.setVisible(false);
        }
    }
	
    public void addButton() {
        for (int i = 1; i <= pictureButton.length - 2; i++) {
            for (int j = 1; j <= pictureButton[i].length - 2; j++) {
                pictureButton[i][j] = new Button("",
                        new ImageView(new Image("" + pictureCount[i - 1][j - 1] + ".jpg")));
                gridPane.add(pictureButton[i][j], j, i);
            }
        }
    }
    
    public void decidePictureCount(int pictureNumber, int lenthButton) {
        int flag = pictureNumber;
        // �к���ͼƬ��������һ��Ϊż��
        // ȷ��ΪͼƬ���ִ���Ϊż��
        if (lenthButton % 2 != 0) {
            for (int j = 0; j < pictureCount[0].length; j++) {
                for (int i = 0; i < pictureCount.length; i += 2) {
                    pictureCount[i][j] = flag;
                    pictureCount[i + 1][j] = flag;
                    flag++;
                    if (flag > pictureNumber) {
                        flag = 1;
                    }
                }
            }
        } else {
            for (int i = 0; i < pictureCount.length; i++) {
                for (int j = 0; j < pictureCount[i].length; j += 2) {
                    pictureCount[i][j] = flag;
                    pictureCount[i][j + 1] = flag;
                    flag++;
                    if (flag > pictureNumber) {
                        flag = 1;
                    }
                }
            }
        }
        // �������
        for (int i = 0; i < pictureCount.length; i++) {
            for (int j = 0; j < pictureCount[i].length; j++) {
                int i1 = (int) (Math.random() * pictureCount.length);
                int j1 = (int) (Math.random() * pictureCount[i].length);

                int temp = pictureCount[i][j];
                pictureCount[i][j] = pictureCount[i1][j1];
                pictureCount[i1][j1] = temp;
            }
        }
    }
    
}
