
//�洢��������
public class DataOfGamePane {
    int lenthButton;//�а�ť����
    int wideButton;//�а�ť����
    int pictureNumber;//ͼƬ��
    //��������
    public DataOfGamePane(String gameLevel) {
        switch(gameLevel) {
            case "easy" :{
                this.lenthButton = 4;
                this.wideButton = 4;
                this.pictureNumber = 4;
                break;
            }
            case "normal" : {
                this.lenthButton = 6;
                this.wideButton = 6;
                this.pictureNumber = 8;
                break;
            }
            case "diffcult" : {
                this.lenthButton = 8;
                this.wideButton = 8;
                this.pictureNumber = 15;
                break;
            }
            default : {};
        }
    }
    public DataOfGamePane(int lenthButton, int wideButton) {
        this.lenthButton = lenthButton;
        this.wideButton = wideButton;
        if (lenthButton * wideButton < 30) {
            pictureNumber = 4;
        } else if (lenthButton * wideButton < 50) {
            pictureNumber = 8;
        } else {
            pictureNumber = 15;
        }
    }
}
