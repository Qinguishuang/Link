import javafx.scene.control.Button;

// �ж��ܷ�������
public class HandleEvent {
    private int X, Y;
    private int defaultX, defaultY;
    private int[][] pictureCount;
    public HandleEvent(int X, int Y, int defaultX, int defaultY, int[][] pictureCount) {
        this.X = X;
        this.Y = Y;
        this.defaultX = defaultX;
        this.defaultY = defaultY;
        this.pictureCount = pictureCount;
    }
    public boolean judge(Button[][] pictureButton) {
        if (isSamePicture() == true && (X != defaultX || Y != defaultY)) {
            // 1. �ж��Ƿ����ڣ�
            makeXShorterThanDefaultX();
            if (isAdjacent()) {
                
                return true;
              // 2.�Һ���հ�ť ����·��Զ��������
                // �ж�������ť�м���û�пհ�ť�������
                // �����ж�
             } else if (judgeBetweenYdefaultY(pictureButton)) {
                    return true;
                    // �����ж�
                } else if(judgeBetweenXdefaultX(pictureButton)) {
                    return true;
                } else if(judgeFromYToLeft(pictureButton)) {
                    return true; 
                } else if (judgeFromYToRight(pictureButton)) {
                    return true; 
                } else if(judguFromXToUp(pictureButton)) {
                    return true;
                } else if(judeeFromXToDown(pictureButton)) {
                    return true;
                } else {
                    return false;                    
                }
            
        }
        
        return false;
    }
    
    private void makeXShorterThanDefaultX() {
        if (X > defaultX) {
            int temp = X;
            X = defaultX;
            defaultX = temp;

            temp = Y;
            Y = defaultY;
            defaultY = temp;
        }
    }
    //�ж�ͼƬ�Ƿ���ͬ
    private boolean isSamePicture() {
        return (pictureCount[X - 1][Y - 1] == pictureCount[defaultX - 1][defaultY - 1]);
    }
    //�ж��Ƿ�����
    private boolean isAdjacent() {
        return ((Y == defaultY) && (Math.abs(X - defaultX) == 1)) || ((X == defaultX) && (Math.abs(Y - defaultY) == 1));
    }
    
    private boolean judgeFromYToLeft(Button[][] pictureButton) {
        //X���� defaultX����
        if (Y <= defaultY) {
            for (int i = Y - 1; i >= 0; i--) {
                if (i == 0) {
                    //�����ж�
                    for (int j = 1; j < defaultY; j++) {
                        if (pictureButton[defaultX][j] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                int mark = 0;
                //������һ���հ�ť
                if (pictureButton[X][i] != null) {
                   return false;
                }
                // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                for (int k = i; k < defaultY; k++) {
                    if (pictureButton[defaultX][k] != null) {
                        return false;
                    }
                }
                // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                
                // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                for (int j = X + 1; j < defaultX; j++) {
                    if (pictureButton[j][i] != null) {
                        mark = 1;
                        break;
                    }
                }
                if (mark == 1) {
                    continue;
                }
                return true;
            }//X ���� defaultX ����
        } else {
            //������һ���հ�ť
            for (int i = defaultY - 1; i >= 0; i--) {
                int mark = 0;
                if (i == 0) {
                    for (int j = 1; j < Y; j++) {
                        if (pictureButton[X][j] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                if (pictureButton[defaultX][i] != null) {
                    return false;
                }
                // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                for (int k = i; k < Y; k++) {
                    if (pictureButton[X][k] != null) {
                        return false;
                    }
                }
                // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                
                // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                for (int j = X + 1; j < defaultX; j++) {
                    if (pictureButton[j][i] != null) {
                        mark = 1;
                        break;
                    }
                }
                if (mark == 1) {
                    continue;
                }
                return true;
            }
        }
        return false;
    }

    // ���������ж�
    private boolean judgeFromYToRight(Button[][] pictureButton) {

        if (Y <= defaultY) {
            for (int i = defaultY + 1; i <= pictureButton[0].length -1; i ++) {
                if (i == pictureButton[0].length -1) {
                    for (int j = Y + 1; j <= pictureButton[0].length - 2; j++) {
                        if (pictureButton[X][j] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                int mark = 0;
                //������һ���հ�ť
                if (pictureButton[defaultX][i] != null) {
                    return false;
                }
                // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                for (int j = Y + 1; j <= i; j++) {
                    if (pictureButton[X][j] != null) {
                        return false;
                    }
                }
                // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                
                // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                for (int j = X + 1; j < defaultX; j ++) {
                    if (pictureButton[j][i] != null) {
                        mark = 1;
                        break;
                    }
                }
                if (mark == 1) {
                    continue;
                }
                return true;
            }
        } else {
            for (int i = Y + 1; i <= pictureButton[0].length - 1; i++) {
                int mark = 0;
                if (i == pictureButton[0].length - 1) {
                    for (int j = defaultY + 1; j <= pictureButton[0].length - 2 ; j++) {
                        if (pictureButton[defaultX][j] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                if(pictureButton[X][i] != null) {
                    return false;
                }
                for (int j = defaultY + 1; j <= i; j++) {
                    if (pictureButton[defaultX][j] != null) {
                        return false;
                    }
                }
                for (int j = X + 1; j < defaultX; j++) {
                    if (pictureButton[j][i] != null) {
                        mark = 1;
                        break;
                    }
                }
                if(mark == 1) {
                    continue;
                }
                return true;
            }
        }
        return false;
    }
    
    private boolean judguFromXToUp(Button[][] pictureButton) {

        if (Y <= defaultY) {
            for (int i = X - 1; i >= 0; i--) {
                int mark = 0;
                if (i == 0) {
                    for (int j = 0; j < defaultX; j++) {
                        if (pictureButton[j][defaultY] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                //��һ����ť��ͬ����һ���հ�ť
                if (pictureButton[i][Y] != null) {
                    return false;
                }
                //�ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                for (int j = defaultX - 1; j >= i; j --) {
                    if (pictureButton[j][defaultY] != null) {
                        return false;
                    }
                }
                //��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                //��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ťͬ�п��Ƿ��а�ť
                for (int j = Y + 1; j < defaultY; j++) {
                    if(pictureButton[i][j] != null) {
                        mark = 1;
                        break;
                    }
                }
                if(mark == 1) {
                    continue;
                }
                return true;
            }
        } else {
            for(int i = X - 1; i >= 0; i --) {
                int mark = 0;
                if(i == 0) {
                    for(int j = defaultX - 1; j > 0; j --) {
                        if(pictureButton[j][defaultY] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                if(pictureButton[i][Y] != null) {
                    return false;
                }
                for (int j = defaultX - 1; j >= i; j --) {
                    if(pictureButton[j][defaultY] != null) {
                        return false;
                    }
                }
                for (int j = defaultY; j < Y; j++) {
                    if(pictureButton[i][j] != null) {
                        mark = 1;
                        break;
                    }
                }
                if(mark == 1) {
                    continue;
                }
                return true;
            }
        }
        return false;        
    }
    
    private boolean judeeFromXToDown(Button[][] pictureButton) {
        if (Y < defaultY) {
            for (int i = defaultX + 1; i <= pictureButton.length - 1; i ++) {
                if(i == pictureButton.length - 1) {
                    for (int j = X + 1; j < pictureButton.length - 1; j ++) {
                        if(pictureButton[j][Y] != null) {
                            return false;
                        }
                    }
                    return true;
                }
                int mark = 0;
                //��һ����ť��ͬ����һ���հ�ť
                if(pictureButton[i][defaultY] != null) {
                    return false;
                }
                //�ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť 
                for (int j = X + 1; j <= i; j ++) {
                    if(pictureButton[j][Y] != null) {
                        return false;
                    }
                }
                //��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                
                //��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ťͬ�п��Ƿ��а�ť
                for (int j = Y + 1; j < defaultY; j ++) {
                    if(pictureButton[i][j] != null) {
                        mark = 1;
                        break;
                    }
                }
                if(mark == 1) {
                    continue;
                }
                return true;
            }
        } else {
            for (int i = defaultX + 1; i <= pictureButton.length - 1; i++) {
                int mark = 0;
                if(i == pictureButton.length - 1) {
                    for (int j = X + 1; j < pictureButton.length - 1; j++) {
                        if(pictureButton[j][Y] != null) {
                            return false;
                        }
                    }
                }
                if(pictureButton[i][defaultY] != null) {
                    return false;
                }
                for (int j = X + 1; j <= i; j++) {
                    if(pictureButton[j][Y] != null) {
                        return false;
                    }
                }
                for (int j = defaultY + 1; j < Y; j++) {
                    if(pictureButton[i][j] != null) {
                        mark = 1;
                        break;
                    }
                }
                if(mark == 1) {
                    continue;
                }
                return true;
            }
        }
        return false;
        
    }

    // �����жϣ����������
    private boolean judgeBetweenXdefaultX(Button[][] pictureButton) {
        int mark = 0;
        // �ж�ͬ��
        if (Y == defaultY) {
            for (int i = X + 1; i < defaultX; i++) {
                if (pictureButton[i][Y] != null) {
                    mark = 1;
                    break;
                }
                if (mark == 0) {
                    return true;
                }
            }
        }
        
        if ( Y < defaultY) {
            for (int i = X + 1; i <= defaultX; i++) {
                //��һ���հ�ť
                mark = 0;
                if (pictureButton[i][Y] == null) {
                 // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                    for (int j = i; j < defaultX; j++) {
                        if (pictureButton[j][defaultY] != null) {
                            mark = 1;
                            break;
                        }
                    }
                    if (mark == 1) {
                        continue;
                    }
                 // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                    for (int k = X + 1; k < i; k++) {
                        if (pictureButton[k][Y] != null) {
                            mark = 1;
                            break;
                        }
                    }
                    if (mark == 1) {
                        continue;
                    }
                 // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                    for (int j = Y + 1  ; j < defaultY; j++) {
                        if (pictureButton[i][j] != null) {
                            mark = 1;
                            break;
                        }                       
                    }
                    if (mark == 1) {
                        continue;
                    }
                    return true;
                }
            }
        }
        // defaultX���� X����
        if ( Y > defaultY) {
            for (int i = defaultX - 1; i > X; i--) {
                mark = 0;
                //��һ���հ�ť
                if (pictureButton[i][defaultY] == null) {
                    // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                    for (int j = i; j > defaultX; j--) {
                        if (pictureButton[j][defaultY] != null) {
                            mark = 1;
                            break;
                        }
                    }
                    if (mark == 1) {
                        continue;
                    }
                    // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                    for (int k = defaultX - 1; k > i; k--) {
                        if (pictureButton[k][Y] != null) {
                            mark = 1;
                            break;
                        }
                    }
                    if (mark == 1) {
                        continue;
                    }
                    // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                    for (int j = defaultY + 1  ; j < Y; j++) {
                        if (pictureButton[i][j] != null) {
                            mark = 1;
                            break;
                        }                       
                    }
                    if (mark == 1) {
                        continue;
                    }
                    return true;
                }
            }
        }        
        return false;
    }

    // �����жϣ����������
    private boolean judgeBetweenYdefaultY(Button[][] pictureButton) {
        int mark = 0;
        // �ж�ͬ��
        if (X == defaultX && Y < defaultY) {
            for (int i = Y + 1; i < defaultY; i++) {
                if (pictureButton[X][i] != null) {
                    mark = 1;
                    break;
                }
            }
            if (mark == 0) {
                return true;
            }
        } else  if (X == defaultX && Y > defaultY) {
            for (int i = defaultY + 1; i < Y; i++) {
                if (pictureButton[X][i] != null) {
                    mark = 1;
                    break;
                }
            }
            if (mark == 0) {
                return true;
            }           
        }
        //���¼Ȳ�ͬ���ֲ�ͬ��        //X����   defaultX ����
        if (Y < defaultY) {
            for (int i = Y + 1; i <= defaultY; i++) {
                int flag = 0;
                // ������һ���հ�ť
                if (pictureButton[X][i] == null) {
                    // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                    for (int j = i; j < defaultY; j++) {
                        if (pictureButton[defaultX][j] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                    for (int j = Y + 1; j < i; j++) {
                        if (pictureButton[X][j] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                    for (int j = X + 1; j < defaultX; j++) {
                        if (pictureButton[j][i] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    return true;
                }
            }
        } else {
            for (int i = defaultY + 1; i <= Y; i++) {
                // ������һ���հ�ť
                int flag = 0;
                if(pictureButton[defaultX][i] == null) {
                    // �ڶ�����ť��������հ�ť���ڵ����Ƿ��а�ť
                    for (int j = i; j < Y; j++) {
                        if (pictureButton[X][j] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    // ��һ����ť������ͬ�е��Ǹ��հ�ť֮���Ƿ��а�ť
                    for (int j = defaultY + 1; j < i; j++) {
                        if (pictureButton[defaultX][j] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    // ��һ����ťͬ�е��Ǹ��հ�ť������ڶ�����ť��ͬ�п��Ƿ��а�ť
                    for (int j = X + 1; j < defaultX; j++) {
                        if (pictureButton[j][i] != null) {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1) {
                        continue;
                    }
                    return true;
                }               
            }
        }        
        return false;
    }
    

}
