import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

		//ʤ���Ժ�չʾ����
public class ButtonOverPane {
    void setButtonOverLabel(Button[][] pictureButton, GridPane gridPane) {
        Label buttonOver1 = new Label("��");
        Label buttonOver2 = new Label("ϲ");
        Label buttonOver3 = new Label("ʤ");
        Label buttonOver4 = new Label("��");
        buttonOver1.setTextFill(Color.RED);
        buttonOver2.setTextFill(Color.RED);
        buttonOver3.setTextFill(Color.RED);
        buttonOver4.setTextFill(Color.RED);
        buttonOver1.setFont(Font.font(40));
        buttonOver2.setFont(Font.font(40));
        buttonOver3.setFont(Font.font(40));
        buttonOver4.setFont(Font.font(40));
        gridPane.add(buttonOver1, (pictureButton[0].length) / 2 - 1, (pictureButton.length) / 2 - 1);
        gridPane.add(buttonOver2, (pictureButton[0].length) / 2 + 1, (pictureButton.length) / 2 - 1);
        gridPane.add(buttonOver3, (pictureButton[0].length) / 2 - 1, (pictureButton.length) / 2 + 1);
        gridPane.add(buttonOver4, (pictureButton[0].length) / 2 + 1, (pictureButton.length) / 2 + 1);
        
    }
}
