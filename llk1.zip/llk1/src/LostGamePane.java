import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

		//ʧ���Ժ�չʾ����
public class LostGamePane extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		Stage stage = new Stage();
		VBox vbox = new VBox(20);
		Label l = new Label("��Ϸʧ��!!!");
		l.setTextFill(Color.RED);
		l.setFont(Font.font(20));
		Button sure = new Button("ȷ��");
		vbox.getChildren().addAll(l, sure);
		vbox.setAlignment(Pos.CENTER);
		Scene s = new Scene(vbox, 200, 140);
		stage.setTitle("����");
		stage.setScene(s);
		stage.show();
		sure.setOnMouseClicked(e -> {
			try {
				stage.close();
				primaryStage.close();
				new BeginMain().start(new Stage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
	}

}
